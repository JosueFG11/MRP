---
lovable: true
app_name: Mindful Renewal Path
primary_color: "#F97316"   # warm orange CTA
background_color: "#FAFAF9" # creamy bg
text_color: "#1F2937"
accent_color: "#F5F0E6"     # soft sand cards
---
# Lovable Sync Config
This file tells Lovable to treat the vault as source of truth.