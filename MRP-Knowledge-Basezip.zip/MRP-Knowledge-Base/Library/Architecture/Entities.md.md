---
title: Data Entities
title_es: Entidades de Datos
tags: [architecture, data]
---
# Data Entities

## Key Elements
- Extend User: awakening_activated (bool), mrp_level (1-3), awareness_profile (text)
- ClarityCredit: user_email, balance (num), granted_date, expiry_date (+3 mo)
- All previous Token → Credit renaming applied